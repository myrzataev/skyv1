# Nested Navigation in Flutter using Go Router
## [Tutorial Video on Youtube](https://youtu.be/t0vT8312sSU?si=PpQg29EBLb-l06pd)
![Untitled-1](https://github.com/AmirBayat0/GoRouter-Nested-Navigation/assets/91388754/8c5168ea-2795-4ad4-abb6-dd8aad5dfdfb)
![Untitled](https://github.com/AmirBayat0/GoRouter-Nested-Navigation/assets/91388754/ccf49356-c630-47e3-9dfd-4033e9b213bd)


## This link allows you to support me
* [SUPPORT](https://www.buymeacoffee.com/AmirBayat)

## My Socials:
* [INSTAGRAM](https://www.instagram.com/codewithflexz)
* [YOUTUBE]( https://www.youtube.com/c/ProgrammingWithFlexZ)
* [CONTACT ME](https://amirbayat.dev@gmail.com)
* [FIND MORE](https://zaap.bio/CodeWithFlexz)
