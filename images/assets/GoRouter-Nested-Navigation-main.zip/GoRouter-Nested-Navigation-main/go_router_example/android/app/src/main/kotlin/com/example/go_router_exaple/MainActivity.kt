package com.example.go_router_exaple

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
